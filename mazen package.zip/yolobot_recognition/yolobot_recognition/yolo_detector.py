import rclpy
from rclpy.node import Node
import cv2
import torch
from cv_bridge import CvBridge
from sensor_msgs.msg import Image

class YoloDetector(Node):
    def __init__(self):
        super().__init__('yolo_detector')

        # Load YOLO model
        self.model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)
        self.bridge = CvBridge()

        # Subscribe to camera
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',  # Adjust this if your camera topic is different
            self.image_callback,
            10)

        # Publisher for annotated images
        self.publisher = self.create_publisher(Image, '/camera/image_annotated', 10)

    def image_callback(self, msg):
        cv_image = self.bridge.imgmsg_to_cv2(msg, 'bgr8')

        # Run YOLO object detection
        results = self.model(cv_image)
        for result in results.xyxy[0]:  # x1, y1, x2, y2, conf, class
            x1, y1, x2, y2, conf, cls = result
            label = f'{self.model.names[int(cls)]} {conf:.2f}'
            cv2.rectangle(cv_image, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
            cv2.putText(cv_image, label, (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # Publish annotated image
        img_msg = self.bridge.cv2_to_imgmsg(cv_image, 'bgr8')
        self.publisher.publish(img_msg)

def main(args=None):
    rclpy.init(args=args)
    node = YoloDetector()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
